# Homework 01

Check the folder for details for each exercises.

`GregoireClement_238122.tar` contain the tarball file for exercise 5

Just in case, `tokens.toml` contains the tokens associated with my email address `gregoire.clement@epfl.ch`