To repeat the attack:

1. Go to website `http://com402.epfl.ch/hw1/ex1`
2. Open the console of your browser.
3. Type: `superencryption("gregoire.clement@epfl.ch", "Never send a human to do a machine's job")`
4. Catch the output and use it as password with `gregoire.clement@epfl.ch` as username

Token will be displayed on the webpage.
